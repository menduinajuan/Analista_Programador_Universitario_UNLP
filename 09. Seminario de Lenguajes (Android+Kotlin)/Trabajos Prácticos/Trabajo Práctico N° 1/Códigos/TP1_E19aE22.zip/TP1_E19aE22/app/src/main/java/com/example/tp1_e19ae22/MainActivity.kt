package com.example.tp1_e19ae22

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

@Suppress("DEPRECATION")
class MainActivity : AppCompatActivity() {
    private lateinit var txtContador: TextView
    private var contador = 0
    companion object {
        const val REQUEST_CODE = 1
        const val RESULT_INCREMENTAR = 1
        const val RESULT_DECREMENTAR = 2
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        txtContador = findViewById(R.id.txtContador)
        val btnOperacion = findViewById<Button?>(R.id.btnRealizarOperacion)
        btnOperacion.setOnClickListener {
            //val intent = Intent(this, Operaciones::class.java)
            val intent = Intent("com.example.tp1_e19ae22.OPERACIONES")
            startActivityForResult(intent, REQUEST_CODE)
        }
        if (savedInstanceState != null) {
            contador = savedInstanceState.getInt("contador")
            txtContador.text = contador.toString()
        }
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE) {
            when (resultCode) {
                RESULT_INCREMENTAR -> contador++
                //RESULT_DECREMENTAR -> contador--
                RESULT_DECREMENTAR -> {
                    if (contador > 0) {
                        contador--
                    } else {
                        Toast.makeText(this, "No se puede decrementar. El contador está en 0.", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            txtContador.text = contador.toString()
        }
    }
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("contador", contador)
    }
}